library(testthat)
library(packagedocs)

test_check("packagedocs")
