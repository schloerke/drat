#' @importFrom utils browseURL packageDescription getFromNamespace capture.output getParseData
#' @import tools
NULL
