Version 0.3.6
----------------------------------------------------------------------

FIXES

- In `rd_template()`, if a function or alias had the same name as the package, it was being excluded from the documentation. This is now fixed.

