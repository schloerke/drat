library(testthat)
library(GGally)

test_check("GGally")
