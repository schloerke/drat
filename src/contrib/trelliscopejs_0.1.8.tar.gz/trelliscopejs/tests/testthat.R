library(testthat)
library(trelliscopejs)

test_check("trelliscopejs")
